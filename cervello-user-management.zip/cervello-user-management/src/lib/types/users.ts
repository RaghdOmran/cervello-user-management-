export interface UserFromData {
  email: string;
  emailVerified: boolean;
  firstName: string;
  lastName: string;
  status: boolean;
  userName: string;
}

export interface User extends UserFromData {
  groups: unknown[] | null;
  id: string;
  preferences: Record<string, string>;
}
