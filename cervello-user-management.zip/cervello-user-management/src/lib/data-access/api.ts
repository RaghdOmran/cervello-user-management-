import { UserFromData } from "../types/users";
const apiUrl = "https://api.demo.cervello.io/opum/v1";

export function getUsers() {
  return fetch(`${apiUrl}/users`).then((res) => res.json());
}

export function createUser(user: UserFromData) {
  return fetch(`${apiUrl}/users`, {
    method: "POST",
    body: JSON.stringify(user),
    headers: {
      "Content-Type": "application/json",
    },
  }).then((res) => res.json());
}

export function updateUser(userId: string, user: UserFromData) {
  return fetch(`${apiUrl}/users/${userId}`, {
    method: "PuT",
    body: JSON.stringify(user),
    headers: {
      "Content-Type": "application/json",
    },
  }).then((res) => res.json());
}
