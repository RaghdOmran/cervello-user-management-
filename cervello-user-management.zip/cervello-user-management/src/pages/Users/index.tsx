import { Box, Button, Container, Typography } from "@mui/material";
import { useCallback, useEffect, useState } from "react";
import UsersForm from "../../components/UserForm";
import UsersList from "../../components/UsersList";
import { getUsers } from "../../lib/data-access/api";
import { User } from "../../lib/types/users";

export default function UsersPage() {
  const [userFormOpen, setUserFormOpen] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [userInEdit, setUserInEdit] = useState<User>();
  const [userInDelete, setUserInDelete] = useState<User>();

  const fetchData = useCallback(() => {
    getUsers().then((resp) => {
      setUsers(resp.result);
    });
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return (
    <Container maxWidth="xl">
      <Box
        py={4}
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Typography variant="h4"> App Users </Typography>
        <Button variant="contained" onClick={() => setUserFormOpen(true)}>
          Add User
        </Button>
      </Box>

      <UsersList
        users={users}
        onEditUser={(user) => {
          setUserInEdit(user);
          setUserFormOpen(true);
        }}
        onDeleteUser={(user) => setUserInDelete(user)}
      />
      {userFormOpen && (
        <UsersForm
          open={userFormOpen}
          user={userInEdit}
          handleClose={() => {
            setUserFormOpen(false);
            setUserInEdit(undefined);
          }}
          onSucces={() => fetchData()}
        />
      )}
    </Container>
  );
}
