import React from "react";
import Header from "./components/Header";
import UsersPage from "./pages/Users";

function App() {
  return (
    <>
      <Header />
      <UsersPage />
    </>
  );
}

export default App;
