import {
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
  Button,
} from "@mui/material";
import { useCallback, useEffect } from "react";
import { useForm } from "react-hook-form";
import { createUser, updateUser } from "../../lib/data-access/api";
import { User, UserFromData } from "../../lib/types/users";

interface Props {
  open: boolean;
  user?: User;
  handleClose: () => void;
  onSucces?: () => void;
}

export default function UsersForm({
  open,
  handleClose,
  onSucces,
  user,
}: Props) {
  console.log({ user });
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<UserFromData>({
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      userName: user?.userName || "",
      email: user?.email || "",
    },
  });

  const handleFormSubmit = useCallback(
    (data: UserFromData) => {
      if (user) {
        updateUser(user.id, data).then(() => {
          handleClose();
          onSucces && onSucces();
        });
      } else {
        createUser(data).then(() => {
          handleClose();
          onSucces && onSucces();
        });
      }
    },
    [handleClose, onSucces, user]
  );

  useEffect(() => {
    if (user) {
      reset(user);
    } else {
      reset();
    }
  }, [reset, user]);

  return (
    <Dialog open={open} onClose={handleClose}>
      <DialogTitle>{user ? "Edit User" : "Add User"}</DialogTitle>
      <DialogContent>
        <TextField
          autoFocus
          margin="dense"
          label="First Name"
          fullWidth
          variant="standard"
          {...register("firstName", { required: true })}
          error={"firstName" in errors}
          helperText="Enter First Name"
        />
        <TextField
          autoFocus
          margin="dense"
          label="Last Name"
          fullWidth
          variant="standard"
          {...register("lastName", { required: true })}
          error={"lastName" in errors}
          helperText="Enter Last Name"
        />
        <TextField
          autoFocus
          margin="dense"
          label="User Name"
          fullWidth
          variant="standard"
          {...register("userName", { required: true })}
          error={"userName" in errors}
          helperText="Enter User Name"
        />

        <TextField
          autoFocus
          margin="dense"
          label="Email Address"
          type="email"
          fullWidth
          variant="standard"
          {...register("email", { required: true })}
          error={"email" in errors}
          helperText="Enter Your Email"
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        <Button onClick={handleSubmit(handleFormSubmit)}>Submit</Button>
      </DialogActions>
    </Dialog>
  );
}
