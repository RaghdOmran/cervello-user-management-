import {
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  IconButton,
} from "@mui/material";
import { Delete, Edit } from "@mui/icons-material";
import { User } from "../../lib/types/users";

interface Props {
  users: User[];
  onDeleteUser: (user: User) => void;
  onEditUser: (user: User) => void;
}

export default function UsersList({ users, onDeleteUser, onEditUser }: Props) {
  return (
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>#</TableCell>
            <TableCell>First Name</TableCell>
            <TableCell align="right">Last Name</TableCell>
            <TableCell align="right">User Name</TableCell>
            <TableCell align="right">Email</TableCell>
            <TableCell align="right">Verified</TableCell>
            <TableCell align="right">Acionts</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map((user, index) => (
            <TableRow
              key={user.id}
              sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {index + 1}
              </TableCell>
              <TableCell component="th" scope="row">
                {user.firstName}
              </TableCell>
              <TableCell align="right">{user.lastName}</TableCell>
              <TableCell align="right">{user.userName}</TableCell>
              <TableCell align="right">{user.email}</TableCell>
              <TableCell align="right">
                {user.emailVerified ? "Verified" : "Not Verified"}
              </TableCell>
              <TableCell align="right">
                <IconButton aria-label="Edit" onClick={() => onEditUser(user)}>
                  <Edit color="primary" />
                </IconButton>
                <IconButton
                  aria-label="delete"
                  onClick={() => onDeleteUser(user)}
                >
                  <Delete color="error" />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
